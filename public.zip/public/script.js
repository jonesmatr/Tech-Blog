document.addEventListener("DOMContentLoaded", function() {
    // Your code here. For example:
    console.log("Client-side script loaded!");

    // Add event listeners, manipulate the DOM, etc.
});
